# Staging
This repository is staging area for Ro-Man 2019 event static website.
This repo contains static code for staging website of Ro-Man 2019 event website.
No changes or modification requests to this repo are solicited.
If required to fork this repo, please do so responsibly.

var typed = new Typewriter('#fill', {
strings: ['Friendly', 'Social', 'Humane'],
autoStart: true,
loop: true,
});
